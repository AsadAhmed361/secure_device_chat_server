#include "SecureChatClient.h"

// ============================================================
// Constructor
// ============================================================

SecureChatClient::SecureChatClient(
    const char* host,
    uint16_t    port,
    const char* token
)
    : _host(host),
      _port(port),
      _token(token),
      _ca_cert(nullptr),
      _authenticated(false),
      _on_message(nullptr),
      _on_connected(nullptr),
      _on_disconnected(nullptr),
      _on_error(nullptr)
{
    _device_id[0] = '\0';
}


// ============================================================
// Configuration
// ============================================================

void SecureChatClient::setCACert(const char* ca_cert) {
    _ca_cert = ca_cert;
}


// ============================================================
// Callbacks
// ============================================================

void SecureChatClient::onMessage(OnMessageCallback cb)           { _on_message      = cb; }
void SecureChatClient::onConnected(OnConnectedCallback cb)       { _on_connected    = cb; }
void SecureChatClient::onDisconnected(OnDisconnectedCallback cb) { _on_disconnected = cb; }
void SecureChatClient::onError(OnErrorCallback cb)               { _on_error        = cb; }


// ============================================================
// connect()
// ============================================================

bool SecureChatClient::connect() {

    // ── TLS setup ──────────────────────────────────────────
    if (_ca_cert) {
        _client.setCACert(_ca_cert);
    } else {
        // Development mode: skip certificate verification.
        // In production, provide a CA cert via setCACert().
        _client.setInsecure();
    }

    // ── TCP + TLS handshake ───────────────────────────────
    if (!_client.connect(_host, _port)) {
        if (_on_error) _on_error("TCP/TLS connection failed");
        return false;
    }

    // ── Authentication handshake ──────────────────────────
    // Build: {"type":"connect","token":"<token>"}\n
    StaticJsonDocument<256> doc;
    doc["type"]  = "connect";
    doc["token"] = _token;

    char buf[256];
    serializeJson(doc, buf, sizeof(buf));
    strncat(buf, "\n", sizeof(buf) - strlen(buf) - 1);

    if (!sendRaw(buf)) {
        if (_on_error) _on_error("Failed to send connect message");
        _client.stop();
        return false;
    }

    // ── Wait for "connected" response ─────────────────────
    char line[MAX_LINE];
    unsigned long deadline = millis() + 5000;   // 5-second timeout

    while (millis() < deadline) {

        if (readLine(line, sizeof(line))) {

            StaticJsonDocument<256> resp;
            DeserializationError err = deserializeJson(resp, line);

            if (err) {
                if (_on_error) _on_error("Bad JSON in connect response");
                _client.stop();
                return false;
            }

            const char* type = resp["type"];

            if (type && strcmp(type, "connected") == 0) {
                const char* id = resp["device_id"];
                if (id) strncpy(_device_id, id, sizeof(_device_id) - 1);
                _authenticated = true;
                if (_on_connected) _on_connected(_device_id);
                return true;
            }
        }

        delay(10);
    }

    if (_on_error) _on_error("Timeout waiting for connected response");
    _client.stop();
    return false;
}


// ============================================================
// loop()   — call this in your Arduino loop()
// ============================================================

void SecureChatClient::loop() {

    if (!_client.connected()) {
        if (_authenticated) {
            _authenticated = false;
            _device_id[0]  = '\0';
            if (_on_disconnected) _on_disconnected();
        }
        return;
    }

    // Read all available lines (non-blocking)
    char line[MAX_LINE];
    while (_client.available() > 0) {
        if (readLine(line, sizeof(line))) {
            handleMessage(line);
        }
    }
}


// ============================================================
// disconnect()
// ============================================================

void SecureChatClient::disconnect() {
    _client.stop();
    _authenticated = false;
    _device_id[0]  = '\0';
    if (_on_disconnected) _on_disconnected();
}


// ============================================================
// subscribe()
// ============================================================

bool SecureChatClient::subscribe(const char* room) {

    if (!_authenticated) {
        if (_on_error) _on_error("Cannot subscribe: not authenticated");
        return false;
    }

    // Build: {"type":"join","room":"<room>"}\n
    StaticJsonDocument<256> doc;
    doc["type"] = "join";
    doc["room"] = room;

    char buf[256];
    serializeJson(doc, buf, sizeof(buf));
    strncat(buf, "\n", sizeof(buf) - strlen(buf) - 1);

    return sendRaw(buf);
}


// ============================================================
// publish()   — raw JSON string as data payload
// ============================================================

bool SecureChatClient::publish(const char* room, const char* json_data) {

    if (!_authenticated) {
        if (_on_error) _on_error("Cannot publish: not authenticated");
        return false;
    }

    // Build the outer envelope manually to avoid double-parsing
    // the json_data string (it may be any valid JSON value).
    char buf[MAX_LINE];
    snprintf(
        buf, sizeof(buf),
        "{\"type\":\"message\",\"room\":\"%s\",\"data\":%s}\n",
        room,
        json_data
    );

    return sendRaw(buf);
}


// ============================================================
// publishValue()   — single float key/value shorthand
// ============================================================

bool SecureChatClient::publishValue(
    const char* room,
    const char* key,
    float       value,
    uint8_t     decimals
) {
    char data[128];
    char fmt[16];
    snprintf(fmt, sizeof(fmt), "{\"%%s\":%%.*f}", decimals);
    snprintf(data, sizeof(data), fmt, key, decimals, value);
    // Simpler: build directly
    char data2[128];
    snprintf(data2, sizeof(data2), "{\"%s\":%.*f}", key, decimals, value);
    return publish(room, data2);
}


// ============================================================
// publishInt()   — single integer key/value shorthand
// ============================================================

bool SecureChatClient::publishInt(
    const char* room,
    const char* key,
    long        value
) {
    char data[128];
    snprintf(data, sizeof(data), "{\"%s\":%ld}", key, value);
    return publish(room, data);
}


// ============================================================
// Status
// ============================================================

bool SecureChatClient::isConnected() const {
    return _authenticated && _client.connected();
}

const char* SecureChatClient::deviceId() const {
    return _device_id;
}


// ============================================================
// sendRaw()   — internal: write a newline-terminated line
// ============================================================

bool SecureChatClient::sendRaw(const char* json_line) {
    if (!_client.connected()) return false;
    size_t len     = strlen(json_line);
    size_t written = _client.write((const uint8_t*)json_line, len);
    return written == len;
}


// ============================================================
// readLine()   — internal: read until '\n' or buffer full
// ============================================================

bool SecureChatClient::readLine(char* buf, size_t max_len) {

    size_t pos = 0;

    while (_client.available() > 0 && pos < max_len - 1) {
        char c = (char)_client.read();
        if (c == '\n') {
            buf[pos] = '\0';
            return pos > 0;
        }
        buf[pos++] = c;
    }

    // No newline yet — partial line, not ready
    return false;
}


// ============================================================
// handleMessage()   — internal: parse and dispatch callbacks
// ============================================================

void SecureChatClient::handleMessage(const char* json_line) {

    // Use a larger document because "data" can be an object
    DynamicJsonDocument doc(MAX_LINE);
    DeserializationError err = deserializeJson(doc, json_line);

    if (err) {
        if (_on_error) _on_error("Failed to parse incoming message");
        return;
    }

    const char* type = doc["type"];

    if (!type) return;

    // ── Broadcast message ─────────────────────────────────
    if (strcmp(type, "message") == 0) {

        if (!_on_message) return;

        const char* room      = doc["room"]      | "";
        const char* from      = doc["from"]      | "";
        unsigned long ts      = doc["timestamp"] | 0UL;

        // Re-serialize "data" back to a JSON string so the
        // callback receives a portable string, not a JsonVariant.
        char data_str[MAX_LINE];
        serializeJson(doc["data"], data_str, sizeof(data_str));

        _on_message(room, from, data_str, ts);
    }
}
