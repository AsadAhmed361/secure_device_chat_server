#ifndef SECURE_CHAT_CLIENT_H
#define SECURE_CHAT_CLIENT_H

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

// ============================================================
// Callback types
// ============================================================

typedef void (*OnMessageCallback)(
    const char* room,
    const char* from,
    const char* data,
    unsigned long timestamp
);

typedef void (*OnConnectedCallback)(const char* device_id);
typedef void (*OnDisconnectedCallback)();
typedef void (*OnErrorCallback)(const char* error);


// ============================================================
// SecureChatClient
// ============================================================

class SecureChatClient {

public:

    // --------------------------------------------------------
    // Constructor
    // --------------------------------------------------------

    SecureChatClient(
        const char* host,
        uint16_t    port,
        const char* token
    );

    // --------------------------------------------------------
    // Configuration
    // --------------------------------------------------------

    // Set a CA certificate for TLS verification (recommended
    // for production). Pass nullptr to skip verification
    // (development / self-signed certs).
    void setCACert(const char* ca_cert);

    // --------------------------------------------------------
    // Callbacks
    // --------------------------------------------------------

    void onMessage(OnMessageCallback cb);
    void onConnected(OnConnectedCallback cb);
    void onDisconnected(OnDisconnectedCallback cb);
    void onError(OnErrorCallback cb);

    // --------------------------------------------------------
    // Lifecycle
    // --------------------------------------------------------

    // Establish TLS connection and authenticate with the server.
    // Returns true on success.
    bool connect();

    // Must be called repeatedly in loop(). Reads incoming
    // messages and dispatches callbacks.
    void loop();

    // Gracefully close the connection.
    void disconnect();

    // --------------------------------------------------------
    // Protocol
    // --------------------------------------------------------

    // Subscribe to a room (must be permitted by your token).
    bool subscribe(const char* room);

    // Publish a raw JSON string as the data payload.
    // Example: publish("factory", "{\"temperature\":34}");
    bool publish(const char* room, const char* json_data);

    // Convenience: publish a single float key/value.
    // Example: publishValue("factory", "temperature", 34.5);
    bool publishValue(
        const char* room,
        const char* key,
        float       value,
        uint8_t     decimals = 2
    );

    // Convenience: publish a single integer key/value.
    bool publishInt(
        const char* room,
        const char* key,
        long        value
    );

    // --------------------------------------------------------
    // Status
    // --------------------------------------------------------

    bool isConnected() const;
    const char* deviceId() const;

private:

    // --------------------------------------------------------
    // Internal helpers
    // --------------------------------------------------------

    bool     sendRaw(const char* json_line);
    bool     readLine(char* buf, size_t max_len);
    void     handleMessage(const char* json_line);

    // --------------------------------------------------------
    // Members
    // --------------------------------------------------------

    const char*     _host;
    uint16_t        _port;
    const char*     _token;
    const char*     _ca_cert;

    char            _device_id[64];
    bool            _authenticated;

    WiFiClientSecure _client;

    OnMessageCallback      _on_message;
    OnConnectedCallback    _on_connected;
    OnDisconnectedCallback _on_disconnected;
    OnErrorCallback        _on_error;

    static const size_t MAX_LINE = 4096;
};

#endif // SECURE_CHAT_CLIENT_H
