// =============================================================
// ESP32 Sender Example
// Mimics sender.py — connects, joins "factory" room, and
// publishes a temperature reading every second.
// =============================================================

#include <WiFi.h>
#include "SecureChatClient.h"

// ── Wi-Fi credentials ─────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ── Server settings ───────────────────────────────────────────
const char* SERVER_HOST   = "192.168.1.100";   // IP of your Python server
const uint16_t SERVER_PORT = 9000;
const char* TOKEN         = "device_token_1";
const char* ROOM          = "factory";

// ── Simulated sensor pin (or use real sensor) ─────────────────
// Replace analogRead() with your actual sensor logic.
const int SENSOR_PIN = 34;

// ── Client instance ───────────────────────────────────────────
SecureChatClient chat(SERVER_HOST, SERVER_PORT, TOKEN);

// ── Publish interval ─────────────────────────────────────────
unsigned long lastPublish = 0;
const unsigned long PUBLISH_INTERVAL_MS = 1000;


// =============================================================
// Callbacks
// =============================================================

void onConnected(const char* device_id) {
    Serial.print("[CONNECTED] device_id = ");
    Serial.println(device_id);
}

void onDisconnected() {
    Serial.println("[DISCONNECTED] Will retry in loop...");
}

void onError(const char* error) {
    Serial.print("[ERROR] ");
    Serial.println(error);
}

// Sender does not normally receive messages, but the callback
// is registered anyway so you can react to alerts etc.
void onMessage(
    const char* room,
    const char* from,
    const char* data,
    unsigned long timestamp
) {
    Serial.print("[MESSAGE] room=");
    Serial.print(room);
    Serial.print(" from=");
    Serial.print(from);
    Serial.print(" data=");
    Serial.println(data);
}


// =============================================================
// connectToServer()   — used in setup and on reconnect
// =============================================================

void connectToServer() {

    Serial.println("[CHAT] Connecting to server...");

    if (!chat.connect()) {
        Serial.println("[CHAT] Connection failed. Will retry.");
        return;
    }

    // Join the room after successful connection
    if (chat.subscribe(ROOM)) {
        Serial.print("[CHAT] Subscribed to room: ");
        Serial.println(ROOM);
    }
}


// =============================================================
// setup()
// =============================================================

void setup() {

    Serial.begin(115200);
    delay(500);

    // ── Register callbacks ────────────────────────────────
    chat.onConnected(onConnected);
    chat.onDisconnected(onDisconnected);
    chat.onError(onError);
    chat.onMessage(onMessage);

    // ── Skip TLS certificate verification ────────────────
    // For production: provide your server CA cert:
    // chat.setCACert(my_ca_cert_pem);
    // (leave this line out and call setCACert() instead)

    // ── Connect to Wi-Fi ──────────────────────────────────
    Serial.print("[WIFI] Connecting to ");
    Serial.println(WIFI_SSID);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.print("[WIFI] Connected. IP: ");
    Serial.println(WiFi.localIP());

    // ── Connect to chat server ────────────────────────────
    connectToServer();
}


// =============================================================
// loop()
// =============================================================

void loop() {

    // ── Keep the client alive and process incoming data ───
    chat.loop();

    // ── Auto-reconnect if connection is lost ──────────────
    if (!chat.isConnected()) {
        delay(3000);
        connectToServer();
        return;
    }

    // ── Publish sensor reading every PUBLISH_INTERVAL_MS ─
    unsigned long now = millis();

    if (now - lastPublish >= PUBLISH_INTERVAL_MS) {
        lastPublish = now;

        // Read sensor value.
        // Replace this with your actual sensor code, e.g.:
        //   float temp = dht.readTemperature();
        float temperature = 20.0f + (analogRead(SENSOR_PIN) / 4095.0f) * 20.0f;

        bool ok = chat.publishValue(ROOM, "temperature", temperature, 1);

        if (ok) {
            Serial.print("[PUBLISHED] temperature = ");
            Serial.println(temperature, 1);
        } else {
            Serial.println("[PUBLISH FAILED]");
        }
    }
}
