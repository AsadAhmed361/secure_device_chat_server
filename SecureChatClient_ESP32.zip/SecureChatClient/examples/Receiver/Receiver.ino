// =============================================================
// ESP32 Receiver Example
// Mimics reciever.py — connects, joins "factory" room, and
// prints every incoming message to Serial.
// =============================================================

#include <WiFi.h>
#include "SecureChatClient.h"

// ── Wi-Fi credentials ─────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ── Server settings ───────────────────────────────────────────
const char* SERVER_HOST    = "192.168.1.100";  // IP of your Python server
const uint16_t SERVER_PORT = 9000;
const char* TOKEN          = "device_token_2";
const char* ROOM           = "factory";

// ── Client instance ───────────────────────────────────────────
SecureChatClient chat(SERVER_HOST, SERVER_PORT, TOKEN);


// =============================================================
// Callbacks
// =============================================================

void onConnected(const char* device_id) {
    Serial.print("[CONNECTED] device_id = ");
    Serial.println(device_id);
}

void onDisconnected() {
    Serial.println("[DISCONNECTED] Will retry in loop...");
}

void onError(const char* error) {
    Serial.print("[ERROR] ");
    Serial.println(error);
}

void onMessage(
    const char* room,
    const char* from,
    const char* data,
    unsigned long timestamp
) {
    // ── Print raw message ─────────────────────────────────
    Serial.println("──────────────────────────");
    Serial.print("  room      : "); Serial.println(room);
    Serial.print("  from      : "); Serial.println(from);
    Serial.print("  timestamp : "); Serial.println(timestamp);
    Serial.print("  data      : "); Serial.println(data);

    // ── Example: parse data and act on a specific field ───
    // If data is {"temperature": 34.5}, you can read the value:
    //
    //   StaticJsonDocument<256> doc;
    //   deserializeJson(doc, data);
    //   float temp = doc["temperature"];
    //   if (temp > 38.0) digitalWrite(ALARM_PIN, HIGH);
    //
    // Add your business logic here.
}


// =============================================================
// connectToServer()   — used in setup and on reconnect
// =============================================================

void connectToServer() {

    Serial.println("[CHAT] Connecting to server...");

    if (!chat.connect()) {
        Serial.println("[CHAT] Connection failed. Will retry.");
        return;
    }

    if (chat.subscribe(ROOM)) {
        Serial.print("[CHAT] Subscribed to room: ");
        Serial.println(ROOM);
    }

    Serial.println("[CHAT] Listening for messages...");
}


// =============================================================
// setup()
// =============================================================

void setup() {

    Serial.begin(115200);
    delay(500);

    // ── Register callbacks ────────────────────────────────
    chat.onConnected(onConnected);
    chat.onDisconnected(onDisconnected);
    chat.onError(onError);
    chat.onMessage(onMessage);

    // ── Skip TLS certificate verification (development) ───
    // For production, use:
    // chat.setCACert(my_ca_cert_pem);

    // ── Connect to Wi-Fi ──────────────────────────────────
    Serial.print("[WIFI] Connecting to ");
    Serial.println(WIFI_SSID);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.print("[WIFI] Connected. IP: ");
    Serial.println(WiFi.localIP());

    // ── Connect to chat server ────────────────────────────
    connectToServer();
}


// =============================================================
// loop()
// =============================================================

void loop() {

    // Process incoming messages and fire callbacks
    chat.loop();

    // Auto-reconnect if connection drops
    if (!chat.isConnected()) {
        delay(3000);
        connectToServer();
    }
}
